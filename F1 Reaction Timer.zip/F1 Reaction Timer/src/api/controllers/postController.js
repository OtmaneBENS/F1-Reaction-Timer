const Post = require('../models/postModel');

exports.listAllPosts = async (req,res) => {
    try {
        const posts = await Post.find({});
        res.status(200).json(posts);
    } catch (error) {
        console.log(error);
        res.status(500).json({message: 'erreur server'});
    }
}

exports.createAPost = async (req, res) => {
    const newPost = new Post(req.body);

    try {
        const post = await newPost.save()
        res.status(201).json(post);
    } catch (error) {
        console.log(error);
        res.status(500).json({message: 'erreur server'});
    }
}

exports.getAPost = async (req, res) => {
    try {
        const post = await Post.findById(req.params.post_id);
        res.status(200).json(post);
    } catch (error) {
        console.log(error);
        res.status(500).json({message: 'erreur server'});
    }
}

exports.updateAPost = async (req,res) => {
    try {
        const post = await Post.findByIdAndUpdate(req.params.post_id, req.body, {new:true});
        res.status(200).json(post);
    } catch (error) {
        console.log(error);
        res.status(500).json({message: 'erreur server'});
    }
}

exports.deleteAPost = async (req,res) => {
    try {
        await Post.findByIdAndDelete(req.params.post_id);
        res.status(200).json({message: 'article supprimé'})
    } catch (error) {
        console.log(error);
        res.status(500).json({message: 'erreur server'});
    }
}