const express = require('express');
const Timer = require('../models/Timer');
const authMiddleware = require('../middleware/authMiddleware');
const router = express.Router();

router.post('/submit-reaction-time', authMiddleware, async (req, res) => {
    const { time } = req.body;
    try {
        const timer = new Timer({
            user_id: req.user.id,
            time
        });
        await timer.save();
        res.status(201).json(timer);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Erreur serveur');
    }
});

router.get('/get-reaction-times/:userId', authMiddleware, async (req, res) => {
    try {
        const timers = await Timer.find({ user_id: req.params.userId }).sort({ date: -1 });
        res.json(timers);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Erreur serveur');
    }
});

module.exports = router;
